#ifndef KERNEL_H
#define KERNEL_H

#include "cuda_runtime.h"
#include "device_launch_parameters.h"

#include <stdio.h>
#include <time.h>
#include <assert.h>

struct uchar4;
struct int2;

float kernelLauncher(uchar4 *d_out, int w, int h, int2 pos);

#endif